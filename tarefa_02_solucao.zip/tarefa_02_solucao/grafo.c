/*
 * Tarefa 02 - Distancias e Caminhos
 *
 * GEN254 - Grafos - 2022/2
 *
 * Nome:      XXXX
 * Matricula: XXXX
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "grafo.h"
#include "fila.h"

struct grafo {
    int num_vertices;
    int num_arestas;
    int **matriz_adj;
};

int **constroi_matriz_int(int m, int n) {
    int **matriz = malloc(m * sizeof(*matriz));

    for (int i = 0; i < m; i++) {
        matriz[i] = malloc(n * sizeof(*(matriz[i])));

        for (int j = 0; j < n; j++) {
            matriz[i][j] = 0;
        }
    }

    return matriz;
}

void destroi_matriz_int(int **matriz, int m) {
    for (int i = 0; i < m; i++) {
        free(matriz[i]);
    }

    free(matriz);
}

bool GRAFOvertice_valido(Grafo *g, int v) {
    if ((v >= 0) && (v <= (g->num_vertices - 1))) {
        return true;
    }

    return false;
}

bool GRAFOaresta_valida(Grafo *g, Aresta e) {
    if (GRAFOvertice_valido(g, e.v1) && GRAFOvertice_valido(g, e.v2)) {
        return true;
    }

    return false;
}

Grafo *GRAFOconstroi(int num_vertices) {
    Grafo *g = malloc(sizeof(*g));

    g->num_vertices = num_vertices;
    g->num_arestas = 0;
    g->matriz_adj = constroi_matriz_int(num_vertices, num_vertices);

    return g;
}

int GRAFOnum_vertices(Grafo *g) {
    return g->num_vertices;
}

int GRAFOnum_arestas(Grafo *g) {
    return g->num_arestas;
}

bool GRAFOtem_aresta(Grafo *g, Aresta e) {
    if (!GRAFOaresta_valida(g, e)) {
        printf("Erro na operacao GRAFOtem_aresta: a aresta %d %d eh "
            "invalida!\n", e.v1, e.v2);
        exit(EXIT_FAILURE);
    }

    return (g->matriz_adj[e.v1][e.v2] != 0);
}

void GRAFOinsere_aresta(Grafo *g, Aresta e) {
    if (!GRAFOaresta_valida(g, e)) {
        printf("Erro na operacao GRAFOinsere_aresta: a aresta %d %d eh "
            "invalida!\n", e.v1, e.v2);
        exit(EXIT_FAILURE);
    }

    if (GRAFOtem_aresta(g, e) || (e.v1 == e.v2)) {
        return;
    }

    g->matriz_adj[e.v1][e.v2] = 1;
    g->matriz_adj[e.v2][e.v1] = 1;

    g->num_arestas++;
}

void GRAFOremove_aresta(Grafo *g, Aresta e) {
    if (!GRAFOaresta_valida(g, e)) {
        printf("Erro na operacao GRAFOremove_aresta: a aresta %d %d eh "
            "invalida!\n", e.v1, e.v2);
        exit(EXIT_FAILURE);
    }

    if (!GRAFOtem_aresta(g, e)) {
        return;
    }

    g->matriz_adj[e.v1][e.v2] = 0;
    g->matriz_adj[e.v2][e.v1] = 0;

    g->num_arestas--;
}

void busca_largura(Grafo *g, int v, bool imprime, int pai_arvore[],
        int dist_raiz[]) {
    Fila *f;
    int w;
    int u;

    if (!GRAFOvertice_valido(g, v)) {
        printf("Erro na operacao busca_largura: o vertice %d eh invalido!\n",
            v);
        exit(EXIT_FAILURE);
    }

    int marcado[g->num_vertices];

    for (u = 0; u < g->num_vertices; u++) {
        marcado[u] = 0;
        pai_arvore[u] = -1;
        dist_raiz[u] = INT_MAX;
    }

    f = FILAconstroi();

    marcado[v] = 1;
    // v nao tem pai na arvore de busca, o que eh representado por
    // pai_arvore[v] ser igual a -1
    dist_raiz[v] = 0;
    FILAinsere(f, v);

    while (!FILAvazia(f)) {
        w = FILAremove(f);
        if (imprime) {
            printf("%d\n", w);
        }

        for (u = 0; u < g->num_vertices; u++) {
            if (g->matriz_adj[w][u] != 0) {
                if (marcado[u] == 0) {
                    marcado[u] = 1;
                    pai_arvore[u] = w;
                    dist_raiz[u] = dist_raiz[w] + 1;
                    FILAinsere(f, u);
                }
            }
        }
    }

    FILAdestroi(f);
}

void GRAFObusca_largura(Grafo *g, int v) {
    if (!GRAFOvertice_valido(g, v)) {
        printf("Erro na operacao GRAFObusca_largura: o vertice %d eh "
            "invalido!\n", v);
        exit(EXIT_FAILURE);
    }

    // Ponto de melhoria: Adicionar estes vetores na struct que representa o
    // grafo e alocar memoria para eles apenas na primeira vez que eles sao
    // utilizados
    int pai[g->num_vertices];
    int dist[g->num_vertices];

    busca_largura(g, v, true, pai, dist);
}

void GRAFOimprime_distancias_caminhos(Grafo *g, int v) {
    if (!GRAFOvertice_valido(g, v)) {
        printf("Erro na operacao GRAFOimprime_distancias_caminhos: o vertice "
            "%d eh invalido!\n", v);
        exit(EXIT_FAILURE);
    }

    // Ponto de melhoria: Adicionar estes vetores na struct que representa o
    // grafo e alocar memoria para eles apenas na primeira vez que eles sao
    // utilizados
    int pai[g->num_vertices];
    int dist[g->num_vertices];

    busca_largura(g, v, false, pai, dist);

    // Inicializa o numero de vertices da componente conexa que contem v
    int comp_con_num_verts = 1;

    // Inicializa a maior distancia finita entre um vertice e v
    int maior_dist_fin = 0;

    for (int u = 0; u < g->num_vertices; u++) {
        if (u == v) {
            printf("%d: %d, %d\n", u, dist[u], u);
        }
        else if (pai[u] == -1) {
            printf("%d: infinita, sem caminho ate %d\n", u, v);
        }
        else {
            comp_con_num_verts++;

            if (dist[u] > maior_dist_fin) {
                maior_dist_fin = dist[u];
            }

            printf("%d: %d, %d", u, dist[u], u);

            int w = pai[u];
            while (w != -1) {
                printf(" %d", w);

                w = pai[w];
            }
            printf("\n");
        }
    }

    printf("%d\n%d\n", comp_con_num_verts, maior_dist_fin);
}

void GRAFOimprime(Grafo *g) {
    for (int i = 0; i < g->num_vertices; i++) {
        printf("%d:", i);

        for (int j = 0; j < g->num_vertices; j++) {
            if (g->matriz_adj[i][j] != 0) {
                printf(" %d", j);
            }
        }

        printf("\n");
    }
}

void GRAFOdestroi(Grafo *g) {
    destroi_matriz_int(g->matriz_adj, g->num_vertices);

    free(g);
}
