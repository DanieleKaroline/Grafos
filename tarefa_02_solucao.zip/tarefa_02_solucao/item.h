/*
 * Tarefa 02 - Distancias e Caminhos
 *
 * GEN254 - Grafos - 2022/2
 *
 * Nome:      XXXX
 * Matricula: XXXX
 */

#ifndef ITEM_H

#define ITEM_H

typedef int Item;

#endif /* ITEM_H */
