#ifndef ARESTA_H

#define ARESTA_H

typedef struct aresta {
    int v1;
    int v2;
} Aresta;

Aresta ARESTA(int v1, int v2);

#endif /* ARESTA_H */
