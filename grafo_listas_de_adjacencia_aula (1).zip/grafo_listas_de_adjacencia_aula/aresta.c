#include <stdio.h>
#include <stdlib.h>
#include "aresta.h"

Aresta ARESTA(int v1, int v2){
    Aresta a;
    a.v1 = v1;
    a.v2 = v2;

    return a;
}
