#include <stdio.h>
#include "aresta.h"
#include "grafo.h"

int main() {
    Grafo *grafo;

    grafo = GRAFOconstroi(4);

    // GRAFOdestroi(grafo);

    return 0;
}
