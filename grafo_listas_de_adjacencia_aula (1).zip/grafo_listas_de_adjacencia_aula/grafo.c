#include <stdio.h>
#include <stdlib.h>
#include "grafo.h"

struct elemListaAdj {
    int v;
    struct elemListaAdj *proximo;
};
typedef struct elemListaAdj ElemListaAdj;

struct grafo {
    int num_v;
    int num_a;
    ElemListaAdj **listas_adj;
};

Grafo *GRAFOconstroi(int num_v) {
    Grafo *g;

    g = malloc(sizeof(*g));

    g->num_v = num_v;
    g->num_a = 0;

    g->listas_adj = malloc(num_v * sizeof(*(g->listas_adj)));

    for (int i = 0; i < num_v; i++) {
        g->listas_adj[i] = NULL;
    }

    return g;
}
